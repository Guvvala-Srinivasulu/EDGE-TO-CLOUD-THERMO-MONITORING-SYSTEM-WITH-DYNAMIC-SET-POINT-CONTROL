#ifndef _DHT11_H_
#define _DHT11_H_

void dht11_request(void);
void dht11_response(void);
unsigned char dht11_data(void);
void DTH_11(void);

#endif
