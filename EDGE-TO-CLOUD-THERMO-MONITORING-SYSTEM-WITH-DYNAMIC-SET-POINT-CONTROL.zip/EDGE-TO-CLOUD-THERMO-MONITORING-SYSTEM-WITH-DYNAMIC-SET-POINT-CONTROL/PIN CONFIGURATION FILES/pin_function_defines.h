#ifndef PINFUN_H

#define PINFUN_H


//pin_function_defines.h

#define PIN_FUNC1 0

#define PIN_FUNC2 1

#define PIN_FUNC3 2

#define PIN_FUNC4 3


#define EINT0_0_1 3

#define EINT0_0_3 3

#define EINT0_0_7 3


#endif

