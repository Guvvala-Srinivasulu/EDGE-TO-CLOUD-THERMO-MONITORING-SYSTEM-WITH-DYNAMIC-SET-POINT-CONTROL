#ifndef PINCONNECT_H
#define PINCONNECT_H


//pin_connect_block.h
#include "types.h"

void CfgPortPinFunc(u32 portNo,
	                  u32 pinNo,
                    u32 pinFunc);


#endif
