#ifndef _EINTDEFINES_
#define _EINTDEFINES_

#define EINT0_VIC_CHN0 14
#define EINT1_VIC_CHN0 15
#define EINT0_0_1 2
#define EINT1_0_3 3

#endif
