#include "types.h"
void setting_point(void);
void setting_humidity(void);
void setting_temperature(void);
void Buzzer(void);
